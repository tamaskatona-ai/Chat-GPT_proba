const E=Engine, key='vegvar-save-v1';
let state=E.initial(),storageAvailable=true,selectedBuilding=null;
try{const raw=localStorage.getItem(key);if(raw){const s=JSON.parse(raw);if(s.version===1&&Object.keys(E.buildings).every(k=>Number.isInteger(s.levels?.[k])&&s.levels[k]>=1)&&['wood','metal','food','soldiers','zone','last','wins'].every(k=>Number.isFinite(s[k])&&s[k]>=0)&&Array.isArray(s.log))state=s;}}catch{storageAvailable=false;}
const $=id=>document.getElementById(id);
function save(){try{localStorage.setItem(key,JSON.stringify(state));}catch{storageAvailable=false;}$('saved').textContent=storageAvailable?'● Helyi mentés aktív':'○ Mentés nem elérhető';}
let timer;function toast(message){$('toast').textContent=message;$('toast').style.display='block';clearTimeout(timer);timer=setTimeout(()=>$('toast').style.display='none',4000);}
function log(message){state.log.unshift(message);state.log=state.log.slice(0,5);}
function sync(){E.advance(state,Date.now());const result=E.resolve(state,Date.now());if(result){log(result);toast(result);}}
function render(){const data=[['wood','🪵','FA',state.levels.sawmill*.8],['metal','⚙️','FÉM',state.levels.mine*.45],['food','🌾','ÉLELEM',state.levels.farm],['soldiers','🪖','KATONÁK',null]];$('resources').innerHTML=data.map(([id,icon,label,rate])=>`<div class="resource"><span class="icon">${icon}</span><div><small>${label}</small><strong>${Math.floor(state[id]).toLocaleString('hu-HU')}</strong><em>${rate===null?'Bevetésre készen':`+${(rate*60).toLocaleString('hu-HU')} / perc`}</em></div></div>`).join('');
$('buildings').innerHTML=Object.entries(E.buildings).map(([id,b])=>{const c=E.cost(state,id),locked=id!=='hq'&&state.levels[id]>=state.levels.hq+1;const disabled=state.mission||locked||Object.entries(c).some(([k,v])=>state[k]<v);return `<article class="building ${selectedBuilding===id?'selected':''}"><span class="level">${state.levels[id]}. SZINT</span><span class="art" aria-hidden="true">${b.icon}</span><h3>${b.name}</h3><p>${b.desc}</p><button data-upgrade="${id}" ${disabled?'disabled':''}>${locked?'Parancsnokság fejlesztése szükséges':`Fejlesztés · ${c.wood} fa / ${c.metal} fém`}</button></article>`;}).join('');
$('power').textContent=E.power(state);$('enemy').textContent=E.enemy(state);$('soldiers').textContent=state.soldiers;$('zones').textContent=String(state.wins).padStart(2,'0');$('rank').textContent=state.levels.hq>3?'Túlélők erődje':'Kezdő település';$('target').textContent=`${state.zone}. körzet · ${['Elhagyott külváros','Romos ipartelep','Fertőzött raktár','Elveszett városközpont'][(state.zone-1)%4]}`;$('forecast').textContent=state.mission?'A csapat felderíti a körzetet…':E.power(state)>=E.enemy(state)?'Erőfölényben vagy. A győzelem várható.':'Az ellenség erősebb. Képezz további katonákat!';$('expedition').disabled=Boolean(state.mission)||state.soldiers<1;$('map-expedition').disabled=$('expedition').disabled;$('map-expedition').textContent=state.mission?'A sereg bevetésen van…':'Sereg indítása →';$('expedition').textContent=state.mission?`Expedíció folyamatban · ${Math.max(0,Math.ceil((state.mission.ends-Date.now())/1000))} mp`:'Expedíció indítása →';$('train').disabled=Boolean(state.mission)||state.food<50||state.metal<20;$('log').replaceChildren(...state.log.map(message=>{const li=document.createElement('li');li.textContent=message;return li;}));}
$('buildings').addEventListener('click',event=>{const button=event.target.closest('[data-upgrade]');if(!button)return;sync();const id=button.dataset.upgrade,error=E.upgrade(state,id);if(error)toast(error);else{log(`${E.buildings[id].name} fejlesztve: ${state.levels[id]}. szint.`);toast('Fejlesztés elkészült!');}save();render();});
$('train').onclick=()=>{sync();const error=E.train(state);if(error)toast(error);else{log('5 új katona csatlakozott a helyőrséghez.');toast('5 katona kiképzése kész!');}save();render();};
$('expedition').onclick=()=>{sync();const error=E.launch(state,Date.now());if(error)toast(error);else {log(`Az expedíció elindult a(z) ${state.zone}. körzetbe.`);$('world-title').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});}save();render();};
$('reset').onclick=()=>{if(confirm('Új települést kezdesz? A jelenlegi haladás törlődik.')){state=E.initial();save();render();}};
sync();save();render();setInterval(()=>{sync();render();save();},1000);document.addEventListener('visibilitychange',()=>{sync();save();render();});

$('map-expedition').onclick=()=>$('expedition').click();
BattleScene.mount($('world-canvas'),()=>state,id=>{
  selectedBuilding=id;
  const button=$('buildings').querySelector(`[data-upgrade="${id}"]`);
  const card=button.closest('.building');
  card.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'center'});
  document.querySelectorAll('.building.selected').forEach(el=>el.classList.remove('selected'));
  card.classList.add('selected');
  toast(`${E.buildings[id].name}: ${state.levels[id]}. szint. A fejlesztéshez használd az épület gombját.`);
});
